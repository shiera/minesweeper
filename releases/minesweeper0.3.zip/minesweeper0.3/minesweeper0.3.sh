#!/bin/bash
java -jar target/minesweeper-0.3.one-jar.jar 

