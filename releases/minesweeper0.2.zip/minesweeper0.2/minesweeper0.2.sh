#!/bin/bash
java -jar target/minesweeper-0.2.one-jar.jar 

