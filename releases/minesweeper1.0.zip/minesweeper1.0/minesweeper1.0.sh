#!/bin/bash
java -jar target/minesweeper-1.0.one-jar.jar 

