minesweeper
===========

minesweeper schoolproject
load the zip file under releases to run.
start the game  whit minesweeper1.0.sh/minesweeper1.0.bat
