#!/bin/bash
java -jar target/minesweeper-1.1.one-jar.jar 

