minesweeper
===========

minesweeper schoolproject

Download the latest zip from the releases folder and extract it.
Start the game with minesweeper1.*.bat on Windows, or minesweeper1.0.sh on Linux.
